/**
 * RemoteControlLib.cpp
 * Copyright (C) 2017 Jude Brauer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RemoteControlLib.h"

int lSpeedPin = 11;
int lDirPin1 = 9;
int lDirPin2 = 8;

int rSpeedPin = 5;
int rDirPin1 = 7;
int rDirPin2 = 6;

int leftSpeed = 0;
int rightSpeed = 0;
int leftDir = 0;
int rightDir = 0;

int usTrigPin = 0;
int usEchoPin = 0;

/**
 * Configures Bluetooth and outputs for Make-A-Pede
 *
 * Should be called in setup()
 */
void setupRemoteControl(int lsp, int ldp1, int ldp2, int rsp, int rdp1, int rdp2) {
  Serial.begin(9600);

  lSpeedPin = lsp;
  lDirPin1 = ldp1;
  lDirPin2 = ldp2;

  rSpeedPin = rsp;
  rDirPin1 = rdp1;
  rDirPin2 = rdp2;

#if defined(__AVR_ATmega32U4__) || defined(__AVR_ATmega16U4__)
  Serial1.begin(9600);
#endif

  pinMode(lSpeedPin, OUTPUT);
  pinMode(lDirPin1, OUTPUT);
  pinMode(lDirPin2, OUTPUT);

  pinMode(rSpeedPin, OUTPUT);
  pinMode(rDirPin1, OUTPUT);
  pinMode(rDirPin2, OUTPUT);
}

void processCommand(char command[]) {
  Serial.println(command);

  int left = 0;
  int right = 0;

  char *p;
  p = strtok(command, ":");
  left = atoi(p);

  p = strtok(NULL, ":");
  right = atoi(p);

  leftSpeed = left - 255;
  rightSpeed = right - 255;

  leftDir = sign(leftSpeed) == 1 ? LOW : HIGH;
  rightDir = sign(rightSpeed) == 1 ? LOW : HIGH;

  leftSpeed = abs(leftSpeed);
  rightSpeed = abs(rightSpeed);

  leftSpeed = constrain(leftSpeed, 0, 255);
  rightSpeed = constrain(rightSpeed, 0, 255);
}

/**
 * Receives and processes messages from connected Bluetooth device.
 *
 * Should be called in loop().
 *
 * Calls userCode() repeatedly.
 */
void bluetoothControl() {
  unsigned long t, t2;
  t = t2 = millis();

  while (true) {
#if defined(__AVR_ATmega32U4__) || defined(__AVR_ATmega16U4__)
    if (Serial1.available() > 0) {
      char command[8];
      Serial1.readBytes(command, 8);
#else
    if (Serial.available() > 0) {
      char command[8];
      Serial.readBytes(command, 8);
#endif
      processCommand(command);

      t = millis();
    }

    if (millis() - t > 5000) {
      leftSpeed = 0;
      rightSpeed = 0;
    }

    userCode();

    setLeftSpeed(leftSpeed);
    setRightSpeed(rightSpeed);

    setLeftDirection(leftDir);
    setRightDirection(rightDir);

    delay(20);
  }
}

/**
 * Set the speed of the left side of the drive in the range of 0-255
 */
void setLeftSpeed(int s) {
  int speed = min(255, s);
  speed = max(0, speed);
  analogWrite(lSpeedPin, speed);
}

/**
 * Set the speed of the right side of the drive in the range of 0-255
 */
void setRightSpeed(int s) {
  int speed = min(255, s);
  speed = max(0, speed);
  analogWrite(rSpeedPin, speed);
}

/**
 * Set the direction of the left side of the drive (LOW (forwards) or HIGH
 * (backwards))
 */
void setLeftDirection(int dir) {
    digitalWrite(lDirPin1, !dir);
    digitalWrite(lDirPin2, dir);
}

/**
 * Set the direction of the right side of the drive (LOW (forwards) or HIGH
 * (backwards))
 */
void setRightDirection(int dir) {
    digitalWrite(rDirPin1, !dir);
    digitalWrite(rDirPin2, dir);
}
